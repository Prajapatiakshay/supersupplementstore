<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WebProductdetail extends Controller
{
    function Productdetail()
    {
        return view('user.Productdetail');
    }
}
