<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class adminlogin_model extends Model
{
    use HasFactory;
    protected $table = "tbl_admin";
    protected $primaryKey = "admin_id";
}
