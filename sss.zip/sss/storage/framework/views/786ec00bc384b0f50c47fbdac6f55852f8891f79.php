

<?php $__env->startSection('title'); ?>
SSS || Track order

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    <!-- BASE CSS -->
    <link href="<?php echo e(URL::to('/')); ?>/user/css/bootstrap.custom.min.css" rel="stylesheet">
    <link href="<?php echo e(URL::to('/')); ?>/user/css/style.css" rel="stylesheet">

	<!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(URL::to('/')); ?>/user/css/error_track.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(URL::to('/')); ?>/user/css/custom.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(URL::to('/')); ?>/user/js/common_scripts.min.js"></script>
    <script src="<?php echo e(URL::to('/')); ?>/user/js/main.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
	
<main class="bg_gray">
		<div id="track_order">
			<div class="container">
				<div class="row justify-content-center text-center">
					<div class="col-xl-7 col-lg-9">
						<img src="<?php echo e(URL::to('/')); ?>/user/img/track_order.svg" alt="" class="img-fluid add_bottom_15" width="200" height="177">
						<p>Quick Tracking Order</p>
						<form>
							<div class="search_bar">
								<input type="text" class="form-control" placeholder="Invoice ID">
								<input type="submit" value="Search">
							</div>
						</form>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /track_order -->
		
		
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("user.usermaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sss\resources\views/user/trackorder.blade.php ENDPATH**/ ?>