<!-- @extand('admin.master.masterpage') -->

<?php $__env->startSection('title'); ?>
SSS | Product - veriation
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/css/responsive.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="vendors/scripts/core.js"></script>
	<script src="vendors/scripts/script.min.js"></script>
	<script src="vendors/scripts/process.js"></script>
	<script src="vendors/scripts/layout-settings.js"></script>
	<script src="src/plugins/datatables/js/jquery.dataTables.min.js"></script>
	<script src="src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
	<script src="src/plugins/datatables/js/dataTables.responsive.min.js"></script>
	<script src="src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
	<!-- buttons for Export datatable -->
	<script src="src/plugins/datatables/js/dataTables.buttons.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.print.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.html5.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.flash.min.js"></script>
	<script src="src/plugins/datatables/js/pdfmake.min.js"></script>
	<script src="src/plugins/datatables/js/vfs_fonts.js"></script>
	<!-- Datatable Setting js -->
	<script src="vendors/scripts/datatable-setting.js"></script></body>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
			<?php if(Session::has('success')): ?>
							<div class="alert alert-success alert-dismissible fade show" role="alert">
								<?php echo e(Session::get('success')); ?>

								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						<?php endif; ?>

						<?php if(Session::has('danger')): ?>
							<div class="alert alert-danger alert-dismissible fade show" role="alert">
								<?php echo e(Session::get('danger')); ?>

								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						<?php endif; ?>
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Manage Product - veriation</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="/Dashbord">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Product - veriation</li>
								</ol>
							</nav>
						</div>
						<div class="col-md-6 col-sm-12 text-right">
							<div class="dropdown">
							<a class="btn btn-primary" href="/Variationadd" role="button">Add Product - veriation</a>
								<div class="dropdown-menu dropdown-menu-right">
									<a class="dropdown-item" href="#">Export List</a>
									<a class="dropdown-item" href="#">Policies</a>
									<a class="dropdown-item" href="#">View Assets</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Simple Datatable start -->
				<div class="card-box mb-30">
					<div class="pd-20">
						<h4 class="text-blue h4">All Products - veriation</h4>
						<!-- <p class="mb-0">you can find more options <a class="text-primary" href="https://datatables.net/" target="_blank">Click Here</a></p> -->
					</div>
					<div class="pb-20">
						<table class="data-table table stripe hover nowrap">
							<thead>
								<tr>
									<th class="table-plus">Sr.no</th>									
									<th>Product Name</th>
									<th>Flaver</th>
									<th>KG</th>
									<th>Selling price</th>
									<th>total Quntity</th>
									<th class="datatable-nosort">Action</th>
								</tr>
							</thead>
							<tbody>
							<?php 
								$i = 0;
							?>
							<?php $__currentLoopData = $var_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							<?php 
								$i++;
							?>
								<tr>
									<td class="table-plus"><?php echo e($i); ?></td>
									<td><?php echo e($row->p_name); ?></td>
									<td><?php echo e($row->flavor); ?></td>
									<td><?php echo e($row->gram); ?></td>
									<td><?php echo e($row->s_price); ?></td>
									<td><?php echo e($row->tot_qty); ?></td>
									<td>
										<div class="dropdown">
											<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
												<i class="dw dw-more"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
												<!-- <a class="dropdown-item" href="#"><i class="dw dw-eye"></i> View verians</a> -->
												<a class="dropdown-item" href="/Veriationedit/<?php echo e($row->var_id); ?>"><i class="dw dw-edit2"></i> Edit</a>
												<a class="dropdown-item btn_delete" data-toggle="modal" data-target="#confirmation-modal" data-id="<?php echo e($row->var_id); ?>" href="#"><i class="dw dw-delete-3"></i> Delete</a>
											</div>
										</div>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</tbody>
						</table>
					</div>
				</div>
				<!-- Simple Datatable End -->
				
				
				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
			@SSS  - Super Supplement Store 2022
			</div>
		</div>
	</div>

					<!-- Confirmation modal -->

							<div class="modal fade" id="confirmation-modal" tabindex="-1" role="dialog" aria-hidden="true">
								<div class="modal-dialog modal-dialog-centered" role="document">
									<div class="modal-content">
									<form action="/Deletevariation" method="post" >
										<div class="modal-body text-center font-18">
											<h4 class="padding-top-30 mb-30 weight-500">Are you sure you want to Delete?</h4>
											<div class="padding-bottom-30 row" style="max-width: 170px; margin: 0 auto;">
												
													<?php echo csrf_field(); ?>
													<input type="hidden" name="hidd_varid" id="hidd_delid">
												
 													<div class="col-6">
														<button type="button" class="btn btn-secondary border-radius-100 btn-block confirmation-btn" data-dismiss="modal"><i class="fa fa-times"></i></button>
														NO
													</div>
													<div class="col-6">
														<button type="submit" class="btn btn-danger border-radius-100 btn-block confirmation-btn" ><i class="fa fa-check"></i></button>
														YES
													</div>
												
											</div>
										</div>
										</form>
									</div>
								</div>
							</div>

					<!-- Confirmation modal end-->

					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
	<script>
		$(document).ready(function(){
			$(".btn_delete").click(function(){
				var del_id = $(this).attr("data-id");
				var del_img = $(this).attr("data-img");
				$("#hidd_delid").val(del_id);
				$("#hidd_delimg").val(del_img);
			});
		})
	</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sss\resources\views/admin/product/variation.blade.php ENDPATH**/ ?>