<!-- @extand('admin.master.masterpage') -->

<?php $__env->startSection('title'); ?>
SSS | Main Category Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/vendors/styles/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/core.js"></script>
	<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/script.min.js"></script>
	<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/process.js"></script>
	<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/layout-settings.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
						<?php if(Session::has('success')): ?>
							<div class="alert alert-success alert-dismissible fade show" role="alert">
								<?php echo e(Session::get('success')); ?>

								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						<?php endif; ?>

						<?php if(Session::has('danger')): ?>
							<div class="alert alert-danger alert-dismissible fade show" role="alert">
								<?php echo e(Session::get('danger')); ?>

								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						<?php endif; ?>
				<div class="page-header">
				<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Manage Main Category</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="/Dashbord">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Main Category</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- Default Basic Forms Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix">
						<div class="pull-left">
							<h4 class="text-blue h4">Edit Main Category</h4>
							<br>
							<!-- <p class="mb-30">All bootstrap element classies</p> -->
						</div>
						
					</div>
					<form id="maincat_form" enctype="multipart/form-data" method="POST" action="/Updatemaincat" >
						<?php echo csrf_field(); ?>

						<input class="form-control" value="<?php echo e($main_data->maincat_id); ?>" type="hidden" name="txtcatid" >
						<input class="form-control" value="<?php echo e($main_data->cat_img); ?>" type="hidden" name="txtoldimage" >

						<div class="form-group row">
							<label class="col-sm-12 col-md-2 col-form-label">Category Name</label>
							<div class="col-sm-12 col-md-10">
								<input class="form-control"  placeholder="Enter main category name" value="<?php echo e($main_data->cat_name); ?>" type="text" name="maincat_name" >
								
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-12 col-md-2 col-form-label">Category Image</label>
							<div class="col-sm-12 col-md-10">
							<input type="file" name="maincat_img" class="form-control-file form-control height-auto">
							<img src="<?php echo e(URL::to('/')); ?>/upload/category/<?php echo e($main_data->cat_img); ?>" style="height: 100px;width: 100px;border-radius: 50%;" >
							</div>
						</div>
						<br>
						<div class="form-group row">
						<div class="col-sm-12 col-md-12">
						<button type="submit" name="action" class="btn btn-primary btn-lg btn-block">Submit</button>
						</div>
						</div>
					</form>
					
				</div>
				<!-- Default Basic Forms End -->
				
				
				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
			@SSS  - Super Supplement Store 2022
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sss\resources\views/admin/category/maincatedit.blade.php ENDPATH**/ ?>