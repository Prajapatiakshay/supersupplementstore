<!-- @extand('admin.master.masterpage') -->

<?php $__env->startSection('title'); ?>
SSS | City Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/vendors/styles/style.css">
	<style>
		.error{
			color: red;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/core.js"></script>
	<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/script.min.js"></script>
	<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/process.js"></script>
	<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/layout-settings.js"></script>

	<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/jquery.validate.js"></script>
	<script src="<?php echo e(URL::to('/')); ?>/vendors/scripts/additional-methods.js"></script>

	<script>
		$(document).ready(function(){
			$("#city_form").validate({
				rules:
				{
					errorElement: 'p',
					errorClass: 'denger',
					state_id:
					{
						required:true
					},
					c_name:
					{
						required:true
					}
				},
				messages:
				{
					state_id:
					{
						required:"Please select state name."
					},
					c_name:
					{
						required:"Please enter city name."
					}
				}
			});
		});
	</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
			<?php if(Session::has('success')): ?>
							<div class="alert alert-success alert-dismissible fade show" role="alert">
								<?php echo e(Session::get('success')); ?>

								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						<?php endif; ?>

						<?php if(Session::has('danger')): ?>
							<div class="alert alert-danger alert-dismissible fade show" role="alert">
								<?php echo e(Session::get('danger')); ?>

								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						<?php endif; ?>
				<div class="page-header">
				<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Manage City</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="/Dashbord">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">City</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- Default Basic Forms Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix">
						<div class="pull-left">
							<h4 class="text-blue h4">Edit City</h4>
						</div>
						
					</div>
					<form id="city_form" method="POST" action="/Updatecity" >
						<?php echo csrf_field(); ?>
						<input type="hidden" name="hidd_city" value="<?php echo e($city_data->city_id); ?>">
						<div class="form-group row">
							<label class="col-sm-12 col-md-2 col-form-label">State name</label>
							<div class="col-sm-12 col-md-10">
							
									<select class="custom-select2 form-control" name="state_id" style="width: 100%; height: 38px;">
									<option value="" >Select state</option>
										<?php $__currentLoopData = $state_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option <?php if($city_data->state_id == $row->state_id): ?> selected <?php endif; ?> value="<?php echo e($row->state_id); ?>"><?php echo e($row->s_name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-sm-12 col-md-2 col-form-label">City name</label>
							<div class="col-sm-12 col-md-10">
								<input class="form-control" value="<?php echo e($city_data->c_name); ?>" type="text" name="c_name" >
							</div>
						</div>
						
						<br>
						<div class="form-group row">
						<div class="col-sm-12 col-md-12">
						<button type="submit" name="action" class="btn btn-primary btn-lg btn-block">Submit</button>
						</div>
						</div>
					</form>


					<div class="collapse collapse-box" id="basic-form1" >
						<div class="code-box">
							<div class="clearfix">
								<a href="javascript:;" class="btn btn-primary btn-sm code-copy pull-left"  data-clipboard-target="#copy-pre"><i class="fa fa-clipboard"></i> Copy Code</a>
								<a href="#basic-form1" class="btn btn-primary btn-sm pull-right" rel="content-y"  data-toggle="collapse" role="button"><i class="fa fa-eye-slash"></i> Hide Code</a>
							</div>
							<pre><code class="xml copy-pre" id="copy-pre">
<form>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Text</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" type="text" placeholder="Johnny Brown">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Search</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" placeholder="Search Here" type="search">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Email</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" value="bootstrap@example.com" type="email">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">URL</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" value="https://getbootstrap.com" type="url">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Telephone</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" value="1-(111)-111-1111" type="tel">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Password</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" value="password" type="password">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Number</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" value="100" type="number">
		</div>
	</div>
	<div class="form-group row">
		<label for="example-datetime-local-input" class="col-sm-12 col-md-2 col-form-label">Date and time</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control datetimepicker" placeholder="Choose Date anf time" type="text">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Date</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control date-picker" placeholder="Select Date" type="text">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Month</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control month-picker" placeholder="Select Month" type="text">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Time</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control time-picker" placeholder="Select time" type="text">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Select</label>
		<div class="col-sm-12 col-md-10">
			<select class="custom-select col-12">
				<option selected="">Choose...</option>
				<option value="1">One</option>
				<option value="2">Two</option>
				<option value="3">Three</option>
			</select>
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Color</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" value="#563d7c" type="color">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-sm-12 col-md-2 col-form-label">Input Range</label>
		<div class="col-sm-12 col-md-10">
			<input class="form-control" value="50" type="range">
		</div>
	</div>
</form>
							</code></pre>
						</div>
					</div>
				</div>
				<!-- Default Basic Forms End -->
				
				
				
			</div>
			<!-- <div class="footer-wrap pd-20 mb-20 card-box">
				DeskApp - Bootstrap 4 Admin Template By <a href="https://github.com/dropways" target="_blank">Ankit Hingarajiya</a>
			</div> -->
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sss\resources\views/admin/city/cityedit.blade.php ENDPATH**/ ?>