<!-- @extand('admin.master.masterpage') -->

<?php $__env->startSection('title'); ?>
SSS | Panding Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/css/responsive.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="vendors/scripts/core.js"></script>
	<script src="vendors/scripts/script.min.js"></script>
	<script src="vendors/scripts/process.js"></script>
	<script src="vendors/scripts/layout-settings.js"></script>
	<script src="src/plugins/datatables/js/jquery.dataTables.min.js"></script>
	<script src="src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
	<script src="src/plugins/datatables/js/dataTables.responsive.min.js"></script>
	<script src="src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
	<!-- buttons for Export datatable -->
	<script src="src/plugins/datatables/js/dataTables.buttons.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.print.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.html5.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.flash.min.js"></script>
	<script src="src/plugins/datatables/js/pdfmake.min.js"></script>
	<script src="src/plugins/datatables/js/vfs_fonts.js"></script>
	<!-- Datatable Setting js -->
	<script src="vendors/scripts/datatable-setting.js"></script></body>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Manage Panding Orders</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="/Dashbord">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Panding Orders</li>
								</ol>
							</nav>
						</div>
						<div class="col-md-6 col-sm-12 text-right">
							<div class="dropdown">
								<a class="btn btn-primary dropdown-toggle" href="#" role="button" data-toggle="dropdown">
									Orders Status
								</a>
								<div class="dropdown-menu dropdown-menu-right">
									<a class="dropdown-item" href="/Pandingorder">Pending Order</a>
									<a class="dropdown-item" href="/Processingorder">Processing Order</a>
									<a class="dropdown-item" href="/Completedorder">Complated Order</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Simple Datatable start -->
				<div class="card-box mb-30">
					<div class="pd-20">
						<h4 class="text-blue h4">All Panding Orders</h4>
						<!-- <p class="mb-0">you can find more options <a class="text-primary" href="https://datatables.net/" target="_blank">Click Here</a></p> -->
					</div>
					<div class="pb-20">
						<table class="data-table table stripe hover nowrap">
							<thead>
								<tr>
									<th class="table-plus datatable-nosort">Sr.no</th>
									<th>UserName</th>
									<th>Product</th>
									<th>Quintity</th>
									<th>Payment</th>
									<th>Payment Mode</th>
									<th>Order Status</th>
									<th class="datatable-nosort"><center>Action</center></th>
								</tr>
							</thead>
							<tbody>

							<?php $__currentLoopData = $pending_ord_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td class="table-plus"><?php echo e($row->ord_id); ?></td>
									<td><?php echo e($row->user_id); ?></td>
									<td><?php echo e($row->pro_id); ?></td>
									<td><?php echo e($row->qty); ?></td>
									<td><?php echo e($row->tot_pay); ?></td>
									<td><?php echo e($row->paymode); ?></td>
									<td><?php echo e($row->ord_statues); ?></td>
									<td><center><button type="button" data-id="<?php echo e($row->ord_id); ?>" id="pan_ord" class="btn btn-primary btn-sm move_proc">Move TO Packging</button></center></td>
									<input type="text" id="hidd_ordid" >
									<!-- <td>
										<div class="dropdown">
											<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
												<i class="dw dw-more"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
												<a class="dropdown-item" href="/Maincatedit"><i class="dw dw-edit2"></i> Edit</a>
												<a class="dropdown-item" href="#"><i class="dw dw-delete-3"></i> Delete</a>
											</div>
										</div>
									</td> -->
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</tbody>
						</table>
					</div>
				</div>
				<!-- Simple Datatable End -->
				
				
				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				DeskApp - Bootstrap 4 Admin Template By <a href="https://github.com/dropways" target="_blank">Ankit Hingarajiya</a>
			</div>
		</div>
	</div>

	

	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
	<script>
		$(document).ready(function(){
			$("#pan_ord").click(function(){
				var del_id = $(this).attr("data-id");
				alert(del_id);
				$("#hidd_ordid").val(del_id);

				window.location.href = '/pending_to_processing/' + del_id;

										// $.ajax({
                                        //     url: 'ajax.php', 
                                        //     type: 'post',
                                        //     data: {ordid:del_id},
                                        //     dataType: 'html',
                                        //     success:function(response){
                                        //         alert(response);
                                                
                                        //         // $("#store").html(response);
                                                
                                        //     }
                                           
                                        // });


			});
		})
	</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sss\resources\views/admin/order/Pandingorder.blade.php ENDPATH**/ ?>